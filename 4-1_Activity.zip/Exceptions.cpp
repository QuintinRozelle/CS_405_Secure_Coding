// Quintin B. Rozelle
// 7/26/24

// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>


// Custom exception class
class myCustomException : public std::exception
{
private:
    std::string exceptionMessage;

public:
    myCustomException(std::string message) : exceptionMessage(message)
    {
    }

    const char* what() const throw()
    {
        return exceptionMessage.c_str();
    }
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  // logic error thrown
  throw std::logic_error("logic_error exception thrown");

  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  // call wrapped in try block
  try
  {
      if(do_even_more_custom_application_logic())
      {
        std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
      }
  }
  // catch any std::exception
  catch (std::exception& e)
  {
      std::cout << "Exception from \"do_even_more_custom_application_logic()\" caught: " << e.what() << std::endl;
  }


  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

  // throw custom exception
  throw myCustomException("myCustomException exception thrown");

  std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception

  // check if den is smaller than the the epsilon value for a float. if true, den is equal to 0
  // necessary to do this as comparing floats can be problematic
  if (std::fabs(den) <= std::numeric_limits<float>::epsilon())
  {
      // invalid argument exception thrown. 0 as den would be an invalid argument
      throw std::invalid_argument("invalid_argument exception thrown. Cannot divide by zero");
  }
  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;

  try
  {
      auto result = divide(numerator, denominator);
      std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  // captures only the invalid_argument exception
  catch (std::invalid_argument& e)
  {
      std::cout << "Exception from \"divide()\" caught: " << e.what() << std::endl;
  }

}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception 
  //  that wraps the whole main function, and displays a message to the console.
  try
  {
      do_division();
      do_custom_application_logic();
  }

  // capture custom exception
  catch (myCustomException& e)
  {
      std::cout << "myCustomException caught in main(): " << e.what() << std::endl;
  }

  // capture std::exception
  catch (std::exception& e)
  {
      std::cout << "std::exception caught in main(): " << e.what() << std::endl;
  }

  // capture any uncaught exceptions
  catch (...)
  {
      std::cout << "uncaught exception caught in main()" << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
